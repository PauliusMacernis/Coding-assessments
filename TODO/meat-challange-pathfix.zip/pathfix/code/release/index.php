<?php

$path = getcwd();

echo 'THE PATH IS: ', $path;


#while (list($var,$value) = each ($_SERVER)) {
#    echo "$var => $value <br />";
# }
